package com.harsh.restapi2.controller;

import com.harsh.restapi2.entity.JornalEntry;
import com.harsh.restapi2.service.JornalEntryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController  //@Component +
@RequestMapping("/journal")
public class JournalEnteryControllerV2 {

    @Autowired
    private JornalEntryService jornalEntryService;

//    @GetMapping("/abc")
    @GetMapping   //http://localhost:8080/journal
    public List<JornalEntry> getAll(){

        return null;
    }


    @PostMapping
    public boolean createEntry(@RequestBody JornalEntry myEntry){
        jornalEntryService.saveEntry(myEntry);
        return true;
    }

    @GetMapping("id/{myid}")
    public JornalEntry getJournaqlEntrybyId(@PathVariable long myid) {
        return null;
    }

    @DeleteMapping("id/{myid}")
    public JornalEntry deleteJournaqlEntrybyId(@PathVariable long myid){
        return null;
    }

    @PutMapping("id/{myid}")
    public JornalEntry UpdateJournaqlEntrybyId(@PathVariable long myid , @RequestBody JornalEntry myentry){
        return null;
}
}
// controller --> srvices --> repository
package com.harsh.restapi2.service;

import com.harsh.restapi2.entity.JornalEntry;
import com.harsh.restapi2.repository.JornalEntryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class JornalEntryService {

    @Autowired
    private JornalEntryRepository jornalEntryRepository;

    public void saveEntry(JornalEntry jornalEntry){
        jornalEntryRepository.save(jornalEntry);
    }
}
